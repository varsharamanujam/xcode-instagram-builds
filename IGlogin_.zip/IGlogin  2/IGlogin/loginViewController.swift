//
//  loginViewController.swift
//  IGlogin
//
//  Created by Varsha Sureshbabu on 28/09/21.
//

import UIKit

class loginViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var Login: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func logintapped(_ sender: Any) {
        
        if let text = email.text,let text4 = password.text, text.isEmpty && text4.isEmpty{
            
            let alert = UIAlertController(title: "Please fill all fields", message: "", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))

            self.present(alert, animated: true)
           
        }
        
        
        if let text = email.text, text.isEmpty {
            let alert = UIAlertController(title: "Enter Email id", message: "", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))

            self.present(alert, animated: true)
           
        }
        if let text = password.text, text.isEmpty {
            let alert = UIAlertController(title: "Enter Password", message: "", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))

            self.present(alert, animated: true)
           
        }
        
    }
    
    
    @IBAction func signuptapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "signup")
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
    
}
