//
//  signupViewController.swift
//  IGlogin
//
//  Created by Varsha Sureshbabu on 28/09/21.
//

import UIKit

class signupViewController: UIViewController {

    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var fullname: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var Signup: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    func isValidEmail(emailID:String) -> Bool {
       let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
       let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
       return emailTest.evaluate(with: emailID)
   }
    @IBAction func signuptapped(_ sender: Any) {
        
        let Email = email.text
        
        if let text = email.text, let text2 = username.text, let text3 = fullname.text, let text4 = password.text, text.isEmpty && text2.isEmpty  && text3.isEmpty  && text4.isEmpty{
            
            let alert = UIAlertController(title: "Please fill all fields", message: "", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))

            self.present(alert, animated: true)
           
        }
      
        
        if let text =  email.text, text.isEmpty || text.count < 10 {
            let alert = UIAlertController(title: "Enter Password", message: "", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))

            self.present(alert, animated: true)
           
        }
        
        if let text =  username.text, text.isEmpty {
            let alert = UIAlertController(title: "Enter Password", message: "", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))

            self.present(alert, animated: true)
           
        }
        
        if let text = fullname.text, text.isEmpty {
            let alert = UIAlertController(title: "Enter Fullname", message: "", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))

            self.present(alert, animated: true)
           
        }
        
        if let text = password.text, text.isEmpty {
            let alert = UIAlertController(title: "Enter Password", message: "", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))

            self.present(alert, animated: true)
           
        }
      
    }
    @IBAction func logintapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "Login")
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
    

}
