//
//  loginViewController.swift
//  instagramloginscreen
//
//  Created by Varsha Sureshbabu on 23/09/21.
//

import UIKit

class loginViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func logintapped(_ sender: Any) {
    }
    @IBAction func loginwithfbtapped(_ sender: Any) {
    }
    @IBAction func forgotpasswordtapped(_ sender: Any) {
    }
    
    @IBAction func signuppagetapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "Signup")
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
    

}
